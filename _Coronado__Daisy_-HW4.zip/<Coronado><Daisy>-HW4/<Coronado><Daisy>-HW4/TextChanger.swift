//
//  TextChanger.swift
//  <Coronado><Daisy>-HW4
//
//  Created by Daisy Coronado on 9/22/23.
//

import Foundation
protocol TextChanger {
    func changeText(newResult:Int)
}
