//
// CollectionViewCell.swift
// <Coronado><Daisy>-HW10
// Filename: CoronadoDaisy-HW10
// EID: dc44789
// Course: CS329E
// Created by Daisy Coronado on 11/28/23.
//
import UIKit

class CollectionViewCell: UICollectionViewCell {
    // create outlet for imageview
    @IBOutlet weak var myView: UIImageView!
}
