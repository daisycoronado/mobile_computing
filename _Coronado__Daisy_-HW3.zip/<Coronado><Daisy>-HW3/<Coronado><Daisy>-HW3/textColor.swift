// textColor.swift
// Project: CoronadoDaisy-HW3
// EID: dc44789
// Course: CS329E
//  Created by Daisy Coronado on 9/20/23.

import Foundation
import UIKit

protocol TextColor{
    func changeColor(newColor:UIColor)
}
