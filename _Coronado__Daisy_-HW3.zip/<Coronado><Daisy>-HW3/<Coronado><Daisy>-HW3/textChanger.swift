//  textChanger.swift
// Project: CoronadoDaisy-HW3
// EID: dc44789
// Course: CS329E
//  Created by Daisy Coronado on 9/20/23.

import Foundation

protocol TextChanger{
    func changeText(newText: String)
}
