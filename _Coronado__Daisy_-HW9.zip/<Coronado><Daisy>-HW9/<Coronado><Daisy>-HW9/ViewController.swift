//
// ViewController.swift
// <Coronado><Daisy>-HW9
// Project: CoronadoDaisy-HW9
// EID: dc44789
// Course: CS329E
// Created by Daisy Coronado on 11/12/23.
//
import UIKit

class ViewController: UIViewController {
    // create vars to be throughout code
    var viewBlock: UIView!
    var timer = Timer()
    var screenHeight: CGFloat = 0.0
    var screenWidth: CGFloat = 0.0
    var activeGestureRecognizer: UISwipeGestureRecognizer?
    var isMovingRight = true
    var safeArea: UILayoutGuide!
    var upFlag: Bool = false
    var downFlag: Bool = false
    var leftFlag: Bool = false
    var rightFlag: Bool = false
    var isMoving: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // safe Area equals the area on the screen for the box to stay within
        let safeArea = view.safeAreaLayoutGuide
        // create the box programmatically
        let blockSize = CGSize(width: safeArea.layoutFrame.width * (1/9) , height: safeArea.layoutFrame.height * (1/19))
        // creates as rectangle
        viewBlock = UIView(frame:CGRect(origin: CGPoint.zero, size: blockSize))
        // sets the color of the box green
        viewBlock.backgroundColor = UIColor.green
        // center the box in the center of the screen
        viewBlock.center = CGPoint(x: safeArea.layoutFrame.midX, y: safeArea.layoutFrame.midY)
        // add box to subview to be shown on screen
        view.addSubview(viewBlock)
        
        // add all gestures to the viewBox programatically
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(tapGestureRecognizer(recognizer:)))
        self.view.addGestureRecognizer(tapRecognizer)
        
        let swipeRightRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(swipeRightGesture(recognizer:)))
        swipeRightRecognizer.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRightRecognizer)
        
        let swipeLeftRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(swipeLeftGesture(recognizer:)))
        swipeLeftRecognizer.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(swipeLeftRecognizer)
        
        let swipeUpRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(swipeUpGesture(recognizer:)))
        swipeUpRecognizer.direction = UISwipeGestureRecognizer.Direction.up
        self.view.addGestureRecognizer(swipeUpRecognizer)
        
        let swipeDownRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(swipeDownGesture(recognizer:)))
        swipeDownRecognizer.direction = UISwipeGestureRecognizer.Direction.down
        self.view.addGestureRecognizer(swipeDownRecognizer)
        
        startBlockDescent()
    }
    // beginning descend
    func startBlockDescent(){
        // centers the block when tapped
        isMoving = true
        viewBlock.center.x = view.center.x
        viewBlock.center.y = view.center.y
        viewBlock.backgroundColor = UIColor.green  // changes the color of the box to green
        // create timer for the box of the box
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            // max height the box can reach
            let maxHeight = self.view.safeAreaLayoutGuide.layoutFrame.maxY - self.viewBlock.frame.size.height / 2
            // adds the height to the location fo the viewblock so it can descend
            self.viewBlock.center.y += self.viewBlock.frame.size.height
            // if the max is greater than or equal to then it will invalidate timer
            if self.viewBlock.frame.maxY >= maxHeight {
                self.timer.invalidate()
                self.viewBlock.backgroundColor = UIColor.red
                self.isMoving = false
            }
        })
    }
    // action occurs when the box is tapped
    @IBAction func tapGestureRecognizer(recognizer: UITapGestureRecognizer) {
        if !isMoving{
            // invalidates the previous timer
            timer.invalidate()
            // set flags to ensure which are activated and which ones arent
            rightFlag = false
            leftFlag = false
            upFlag = false
            downFlag = false
            isMoving = true
            // centers the block when tapped
            viewBlock.center.x = view.center.x
            viewBlock.center.y = view.center.y
            viewBlock.backgroundColor = UIColor.green  // changes the color of the box to green
            // create timer for the box of the box
            timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
                // max height the box can reach
                let maxHeight = self.view.safeAreaLayoutGuide.layoutFrame.maxY - self.viewBlock.frame.size.height / 2
                    // adds the height to the location fo the viewblock so it can descend
                self.viewBlock.center.y += self.viewBlock.frame.size.height
                    // if the max is greater than or equal to then it will invalidate timer
                if self.viewBlock.frame.maxY >= maxHeight {
                    self.timer.invalidate()
                    self.viewBlock.backgroundColor = UIColor.red
                    self.isMoving = false
                }
            })
        }
    }
    // action occurs when user swipes right
    @IBAction func swipeRightGesture(recognizer: UISwipeGestureRecognizer) {
        // invalidates previous timer
        timer.invalidate()
        // set flags to ensure which are activated  and which ones arent
        rightFlag = true
        leftFlag = false
        upFlag = false
        downFlag = false
        isMoving = true
        // create timer to block movement
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            // if statement to makesure block is green and correct flag is true
            if self.viewBlock.backgroundColor == UIColor.green && self.rightFlag == true {
                // max width to constrain block to safe area
                let maxWidth = self.view.safeAreaLayoutGuide.layoutFrame.maxX - self.viewBlock.frame.size.width / 2
                // adds to the location of the block to move it
                self.viewBlock.center.x += self.viewBlock.frame.size.width
                // invalidates timer if it is equal to or greater than maxX
                if self.viewBlock.frame.maxX >= maxWidth {
                    self.timer.invalidate()
                    self.viewBlock.backgroundColor = UIColor.red
                    self.isMoving = false
                }
            }
        })
    }
    // action occure when user swipes left
    @IBAction func swipeLeftGesture(recognizer: UISwipeGestureRecognizer) {
        // invalidates previous timer
        timer.invalidate()
        // sets correct flags
        rightFlag = false
        leftFlag = true
        upFlag = false
        downFlag = false
        isMoving = true
        // creates timer for block movement
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            // if statement to make sure block is green and correct flag is true
            if self.viewBlock.backgroundColor == UIColor.green && self.leftFlag == true{
                //min width to constrain block movement
                let minWidth = self.view.safeAreaLayoutGuide.layoutFrame.minX + self.viewBlock.frame.size.width / 2
                // substracts from block location
                self.viewBlock.center.x -= self.viewBlock.frame.size.width
                // if minX is less or equal to then it will invalidate
                if self.viewBlock.frame.minX <= minWidth{
                    self.timer.invalidate()
                    self.viewBlock.backgroundColor = UIColor.red
                    self.isMoving = false
                    
                }
            }
        })
    }
    // action occurs when user swipes up
    @IBAction func swipeUpGesture(recognizer: UISwipeGestureRecognizer) {
        // invalidates previous timer
        timer.invalidate()
        // sets correct flags
        rightFlag = false
        leftFlag = false
        upFlag = true
        downFlag = false
        isMoving = true
        // timer for block movement
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: { _ in
            // if statement to make sure block is green and correct flag is true
            if self.viewBlock.backgroundColor == UIColor.green && self.upFlag == true{
                // min height box
                let minHeight = self.view.safeAreaLayoutGuide.layoutFrame.minY + self.viewBlock.frame.size.height / 2
                // subtracts from the center to move block
                self.viewBlock.center.y -= self.viewBlock.frame.size.height
                // if true it will invalidate timer
                if self.viewBlock.frame.minY <= minHeight{
                    self.timer.invalidate()
                    self.viewBlock.backgroundColor = UIColor.red
                    self.isMoving = false
                }
            }
        })
    }
    // action occcurs when user swipes down
    @IBAction func swipeDownGesture(recognizer: UISwipeGestureRecognizer) {
        // invalidates previous timer
        timer.invalidate()
        // sets correct flag
        rightFlag = false
        leftFlag = false
        upFlag = false
        downFlag = true
        isMoving = true
        //timer for block movement
        timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: {_ in
            // if statement to make sure block is green and correct flag is true
            if self.viewBlock.backgroundColor == UIColor.green && self.downFlag == true{
                // max height for up movement
                let maxHeight = self.view.safeAreaLayoutGuide.layoutFrame.maxY - self.viewBlock.frame.size.height / 2
                // adds to box location to move it
                self.viewBlock.center.y += self.viewBlock.frame.size.height
                // if maxY is greater than or equal to maxHeight
                if self.viewBlock.frame.maxY >= maxHeight{
                    self.timer.invalidate()
                    self.viewBlock.backgroundColor = UIColor.red
                    self.isMoving = false
                }
            }
        })
    }
}
