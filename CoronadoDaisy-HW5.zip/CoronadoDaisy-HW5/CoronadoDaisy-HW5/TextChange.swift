//
// ViewController.swift
// Project: CoronadoDaisy-HW5
// EID: dc44789
// Course: CS329E
//  Created by Daisy Coronado on 10/10/23.
//
import Foundation
//protocol that will be used to store the newPizza and be shown in main controller
protocol PizzaChanger{
    func pizzaOrder(newPizza: String)
}
