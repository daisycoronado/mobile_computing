//
// AddTimer.swift
// <Coronado><Daisy>-HW7
// Project: CoronadoDaisy-HW7
// EID: dc44789
// Course: CS329E
//  Created by Daisy Coronado on 10/26/23.
//
import Foundation

// protocol to add timer to list of timers
protocol AddTimer {
    func newTimer(addTimer:Timer)
}
