//
// NewTime.swift
// <Coronado><Daisy>-HW7
// Project: CoronadoDaisy-HW7
// EID: dc44789
// Course: CS329E
// Created by Daisy Coronado on 10/30/23.
//
import Foundation

// protocol to set new time in main controller
protocol NewTime {
    func createTime(remainingTimer: String)
}
